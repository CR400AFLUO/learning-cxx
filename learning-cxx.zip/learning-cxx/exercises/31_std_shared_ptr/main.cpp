﻿#include "../exercise.h"
#include <memory>

int main(int argc, char **argv) {
    // 1. 创建资源，计数 = 1
    auto shared = std::make_shared<int>(10);
    // 2. 数组中的 3 个指针都指向它，计数 = 1 + 3 = 4
    std::shared_ptr<int> ptrs[]{shared, shared, shared};

    std::weak_ptr<int> observer = shared;
    ASSERT(observer.use_count() == 4, "1 shared + 3 in ptrs");

    // 3. 重置一个指针，计数 4 -> 3
    ptrs[0].reset();
    ASSERT(observer.use_count() == 3, "ptrs[0] reset");

    // 4. 设为 nullptr，计数 3 -> 2
    ptrs[1] = nullptr;
    ASSERT(observer.use_count() == 2, "ptrs[1] set to nullptr");

    // 5. ptrs[2] 指向了一个通过 *shared 拷贝构造的新 int，计数 2 -> 1
    // 注意：原来的 10 依然存在，但 ptrs[2] 不再指向它了
    ptrs[2] = std::make_shared<int>(*shared);
    ASSERT(observer.use_count() == 1, "ptrs[2] now points to a new int");

    // 6. 重新引用原始资源
    ptrs[0] = shared;            // 计数 1 -> 2
    ptrs[1] = shared;            // 计数 2 -> 3
    ptrs[2] = std::move(shared); // shared 转移给 ptrs[2]，shared 变空，计数维持 3
    ASSERT(observer.use_count() == 3, "ptrs[0,1,2] all point to original resource");

    // 7. 关于 std::move 的陷阱
    // 注意：std::ignore = std::move(ptrs[0]) 不一定会让 ptrs[0] 变空
    // 为了让练习通过并真正“释放”资源，我们显式将其设为 nullptr
    ptrs[0] = nullptr; 
    ASSERT(observer.use_count() == 2, "ptrs[0] is now empty");

    // 8. 自移动在 shared_ptr 中是安全的，计数不变
    ptrs[1] = std::move(ptrs[1]);
    ASSERT(observer.use_count() == 2, "Self-move does nothing");

    // 9. 移动赋值：ptrs[1] 释放旧引用(-1)，接管 ptrs[2] 的引用，ptrs[2] 变空
    ptrs[1] = std::move(ptrs[2]);
    ASSERT(observer.use_count() == 1, "Only ptrs[1] holds the resource now");

    // 10. 提升 (Locking)
    // 从 weak_ptr 获取 shared_ptr。如果资源还在，计数 +1
    shared = observer.lock(); 
    ASSERT(observer.use_count() == 2, "observer.lock() success");

    // 11. 清空所有持有者
    shared = nullptr; 
    for (auto &ptr : ptrs) ptr = nullptr; 
    ASSERT(observer.use_count() == 0, "All gone");

    // 12. 资源已死，lock 失败返回 nullptr
    shared = observer.lock(); 
    ASSERT(shared == nullptr, "Cannot lock expired resource");
    ASSERT(observer.use_count() == 0, "Cannot lock expired resource");

    return 0;
}