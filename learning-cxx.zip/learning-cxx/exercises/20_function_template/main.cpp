﻿#include "../exercise.h"
#include <cmath> // 引入 std::abs 进行浮点数精度判断

// TODO: 将这个函数模板化
// template <typename T> 定义了泛型参数 T，编译器会根据传入的参数自动推导出具体类型
template <typename T>
T plus(T a, T b) {
    return a + b;
}

int main(int argc, char **argv) {
    // 整数测试
    ASSERT(plus(1, 2) == 3, "Plus two int");
    ASSERT(plus(1u, 2u) == 3u, "Plus two unsigned int");

    // THINK: 浮点数何时可以判断 ==？
    // 当数值能被精确地表示为 2 的负幂次之和时（例如 1.25 = 1 + 1/4），== 是安全的。
    ASSERT(plus(1.25f, 2.5f) == 3.75f, "Plus two float");
    ASSERT(plus(1.25, 2.5) == 3.75, "Plus two double");

    // TODO: 修改判断条件使测试通过
    // 在二进制浮点数中，0.1 和 0.2 都是无限循环小数，存在舍入误差
    // 0.1 + 0.2 实际上约等于 0.30000000000000004
    // 在计算机系统中，我们通常判断两数之差是否小于一个极小值（Epsilon）
    auto res = plus(0.1, 0.2);
    ASSERT(std::abs(res - 0.3) < 1e-10, "How to make this pass?");

    return 0;
}