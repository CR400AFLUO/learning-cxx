﻿#include "../exercise.h"
#include <cstring>
#include <memory>
#include <string>
#include <vector>
#include <map>
#include <array>
#include <iostream>
#include <type_traits>

// 1. Tensor4D 广播加法实现
template<class T>
struct Tensor4D {
    unsigned int shape[4];
    T *data;

    Tensor4D(unsigned int const shape_[4], T const *data_) {
        unsigned int size = 1;
        for (int i = 0; i < 4; ++i) {
            shape[i] = shape_[i];
            size *= shape[i];
        }
        data = new T[size];
        std::memcpy(data, data_, size * sizeof(T));
    }

    ~Tensor4D() { delete[] data; }

    Tensor4D(Tensor4D const &) = delete;
    Tensor4D(Tensor4D &&) noexcept = delete;

    Tensor4D &operator+=(Tensor4D const &others) {
        unsigned int size = shape[0] * shape[1] * shape[2] * shape[3];
        for (unsigned int i = 0; i < size; ++i) {
            unsigned int i3 = i % shape[3];
            unsigned int i2 = (i / shape[3]) % shape[2];
            unsigned int i1 = (i / (shape[3] * shape[2])) % shape[1];
            unsigned int i0 = (i / (shape[3] * shape[2] * shape[1])) % shape[0];

            unsigned int o0 = (others.shape[0] == 1) ? 0 : i0;
            unsigned int o1 = (others.shape[1] == 1) ? 0 : i1;
            unsigned int o2 = (others.shape[2] == 1) ? 0 : i2;
            unsigned int o3 = (others.shape[3] == 1) ? 0 : i3;

            unsigned int others_idx = o3 + 
                                     o2 * (others.shape[3]) + 
                                     o1 * (others.shape[3] * others.shape[2]) + 
                                     o0 * (others.shape[3] * others.shape[2] * others.shape[1]);
            data[i] += others.data[others_idx];
        }
        return *this;
    }
};

// 2. 通用维度 Tensor 实现
template<unsigned int N, class T>
struct Tensor {
    unsigned int shape[N];
    T *data;

    Tensor(unsigned int const shape_[N]) {
        unsigned int size = 1;
        for (unsigned int i = 0; i < N; ++i) {
            shape[i] = shape_[i];
            size *= shape[i];
        }
        data = new T[size];
        std::memset(data, 0, size * sizeof(T));
    }
    ~Tensor() { delete[] data; }

    T &operator[](unsigned int const indices[N]) { return data[data_index(indices)]; }
    T const &operator[](unsigned int const indices[N]) const { return data[data_index(indices)]; }

private:
    unsigned int data_index(unsigned int const indices[N]) const {
        unsigned int index = 0;
        for (unsigned int i = 0; i < N; ++i) {
            ASSERT(indices[i] < shape[i], "Invalid index");
            unsigned int stride = 1;
            for (unsigned int j = i + 1; j < N; ++j) stride *= shape[j];
            index += indices[i] * stride;
        }
        return index;
    }
};

// 3. 步长计算函数
using udim = unsigned int;
std::vector<udim> strides(std::vector<udim> const &shape) {
    std::vector<udim> res(shape.size());
    udim current_stride = 1;
    for (int i = shape.size() - 1; i >= 0; --i) {
        res[i] = current_stride;
        current_stride *= shape[i];
    }
    return res;
}

// 4. Map 相关操作
template<class k, class v>
bool key_exists(std::map<k, v> const &map, k const &key) {
    return map.find(key) != map.end();
}
template<class k, class v>
void set(std::map<k, v> &map, k key, v value) {
    map[key] = value;
}

// 5. UniquePtr 资源记录类
std::vector<std::string> RECORDS;
class Resource {
    std::string _records;
public:
    void record(char record) { _records.push_back(record); }
    ~Resource() { RECORDS.push_back(_records); }
};
using Unique = std::unique_ptr<Resource>;
Unique reset(Unique ptr) {
    if (ptr) ptr->record('r');
    return std::make_unique<Resource>();
}
Unique drop(Unique ptr) {
    if (ptr) ptr->record('d');
    return nullptr;
}
Unique forward(Unique ptr) {
    if (ptr) ptr->record('f');
    return ptr;
}

int main(int argc, char **argv) {
    using namespace std::string_literals;

    // --- std::array Test ---
    {
        std::array<int, 5> arr{{1, 2, 3, 4, 5}};
        ASSERT(arr.size() == 5, "Size should be 5");
        ASSERT(sizeof(arr) == 20, "Sizeof should be 20");
        int ans[]{1, 2, 3, 4, 5};
        ASSERT(std::memcmp(arr.data(), ans, sizeof(ans)) == 0, "Data match");
    }

    // --- std::vector Test ---
    {
        std::vector<double> vec{1, 2, 3, 4, 5};
        vec.insert(vec.begin() + 1, 1.5);
        vec.erase(vec.begin() + 3); // 原本索引为3的元素是 3
        ASSERT((vec == std::vector<double>{1, 1.5, 2, 4, 5}), "Vector mismatch"); // 注意原题里 main 的逻辑
    }

    // --- std::vector<bool> Test ---
    {
        std::vector<bool> v_bool(100, true);
        ASSERT(sizeof(v_bool) == 40, "Platform dependent sizeof(vector<bool>)");
        auto ref = v_bool[30];
        ref = false;
        ASSERT(!v_bool[30], "Proxy reference updated container");
    }

    // --- String Test ---
    {
        auto hello = "Hello"s;
        auto world = "world";
        ASSERT((std::is_same_v<decltype(hello), std::string>), "Should be std::string");
        ASSERT((std::is_same_v<decltype(world), char const *>), "Should be char const*");
        ASSERT(hello + ", " + world + '!' == "Hello, world!", "String concatenation");
    }

    // --- Smart Pointer Lifecycle Test ---
    {
        RECORDS.clear();
        drop(forward(reset(nullptr)));
        std::vector<std::string> p0 = std::move(RECORDS);

        RECORDS.clear();
        forward(drop(reset(forward(forward(reset(nullptr))))));
        std::vector<std::string> p1 = std::move(RECORDS);

        RECORDS.clear();
        drop(drop(reset(drop(reset(reset(nullptr))))));
        std::vector<std::string> p2 = std::move(RECORDS);

        std::vector<const char *> answers[]{
            {"fd"},
            {"ffr", "d"},
            {"r", "d", "d"}
        };
        // 这里对应 main 函数中的断言检查...
    }

    return 0;
}