﻿#include "../exercise.h"
#include <array>
#include <cstring>

// READ: std::array <https://zh.cppreference.com/w/cpp/container/array>

int main(int argc, char **argv) {
    {
        std::array<int, 5> arr{{1, 2, 3, 4, 5}};
        // size() 是元素个数，即 5
        ASSERT(arr.size() == 5, "Fill in the correct value.");
        // sizeof() 是总字节数，int 通常占 4 字节，5 * 4 = 20
        ASSERT(sizeof(arr) == 20, "Fill in the correct value.");
        int ans[]{1, 2, 3, 4, 5};
        // data() 获取首地址，比较的长度是 5 个 int 的字节数
        ASSERT(std::memcmp(arr.data(), ans, sizeof(ans)) == 0, "Fill in the correct values.");
    }
    {
        std::array<double, 8> arr;
        // size() 是元素个数，即 8
        ASSERT(arr.size() == 8, "Fill in the correct value.");
        // double 通常占 8 字节，8 * 8 = 64
        ASSERT(sizeof(arr) == 64, "Fill in the correct value.");
    }
    {
        // 字符串 "Hello, InfiniTensor!" 包含 20 个字符 + 1 个终止符 '\0'
        std::array<char, 21> arr{"Hello, InfiniTensor!"};
        ASSERT(arr.size() == 21, "Fill in the correct value.");
        // char 占 1 字节，21 * 1 = 21
        ASSERT(sizeof(arr) == 21, "Fill in the correct value.");
        // strcmp 需要一个 const char*，可以通过 .data() 或 &.front() 获取
        ASSERT(std::strcmp(arr.data(), "Hello, InfiniTensor!") == 0, "Fill in the correct value.");
    }
    return 0;
}