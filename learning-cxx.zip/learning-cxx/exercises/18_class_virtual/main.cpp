#include "../exercise.h"

// READ: 虚函数 <https://zh.cppreference.com/w/cpp/language/virtual>

struct A {
    virtual char virtual_name() const {
        return 'A';
    }
    char direct_name() const {
        return 'A';
    }
};
struct B : public A {
    // READ: override <https://zh.cppreference.com/w/cpp/language/override>
    char virtual_name() const override {
        return 'B';
    }
    char direct_name() const {
        return 'B';
    }
};
struct C : public B {
    // READ: final <https://zh.cppreference.com/w/cpp/language/final>
    char virtual_name() const final {
        return 'C';
    }
    char direct_name() const {
        return 'C';
    }
};
struct D : public C {
    char direct_name() const {
        return 'D';
    }
};

int main(int argc, char **argv) {
    constexpr auto MSG = "Replace '?' with its correct name.";

    A a;
    B b;
    C c;
    D d;

    // --- 第一部分：直接对象调用 ---
    // 逻辑：对象是什么类型，就调用对应类里的函数
    ASSERT(a.virtual_name() == 'A', MSG);
    ASSERT(b.virtual_name() == 'B', MSG);
    ASSERT(c.virtual_name() == 'C', MSG);
    ASSERT(d.virtual_name() == 'C', MSG); // D没有重写，沿用C的final实现
    
    ASSERT(a.direct_name() == 'A', MSG);
    ASSERT(b.direct_name() == 'B', MSG);
    ASSERT(c.direct_name() == 'C', MSG);
    ASSERT(d.direct_name() == 'D', MSG);

    // --- 第二部分：通过基类引用调用 ---
    // 逻辑：虚函数看“运行时的对象”，普通函数看“编译时的引用类型”
    A &rab = b;
    B &rbc = c;
    C &rcd = d;

    // 虚函数：动态绑定
    ASSERT(rab.virtual_name() == 'B', MSG); // 对象是B
    ASSERT(rbc.virtual_name() == 'C', MSG); // 对象是C
    ASSERT(rcd.virtual_name() == 'C', MSG); // 对象是D，但执行的是C::final

    // 普通函数：静态绑定
    ASSERT(rab.direct_name() == 'A', MSG);  // 引用类型是A
    ASSERT(rbc.direct_name() == 'B', MSG);  // 引用类型是B
    ASSERT(rcd.direct_name() == 'C', MSG);  // 引用类型是C

    // --- 第三部分：跨级引用 ---
    A &rac = c;
    B &rbd = d;

    ASSERT(rac.virtual_name() == 'C', MSG); // 对象是C
    ASSERT(rbd.virtual_name() == 'C', MSG); // 对象是D，执行C的实现
    ASSERT(rac.direct_name() == 'A', MSG);  // 引用类型是A
    ASSERT(rbd.direct_name() == 'B', MSG);  // 引用类型是B

    // --- 第四部分：顶级基类引用派生最深的对象 ---
    A &rad = d;

    ASSERT(rad.virtual_name() == 'C', MSG); // 依然执行到C就停止了
    ASSERT(rad.direct_name() == 'A', MSG);  // 引用类型是A

    return 0;
}