#include "../exercise.h"

// READ: 静态字段 <https://zh.cppreference.com/w/cpp/language/static>
// READ: 虚析构函数 <https://zh.cppreference.com/w/cpp/language/destructor>

struct A {
    // 声明静态字段
    static int num_a;

    A() {
        ++num_a;
    }
    // TODO: ---- 修改类定义解决编译/逻辑问题 ----
    // 必须是虚析构函数，否则通过基类指针删除派生类对象时，派生类析构函数不会被调用
    virtual ~A() {
        --num_a;
    }

    virtual char name() const {
        return 'A';
    }
};

// 在类外初始化静态字段
int A::num_a = 0;

struct B final : public A {
    // 声明静态字段
    static int num_b;

    B() {
        ++num_b;
    }
    ~B() {
        --num_b;
    }

    char name() const final {
        return 'B';
    }
};

// 在类外初始化静态字段
int B::num_b = 0;

int main(int argc, char **argv) {
    auto a = new A;
    auto b = new B; // B 继承自 A，所以构造 B 时会先调用 A()，再调用 B()
    
    ASSERT(A::num_a == 2, "a 贡献了 1 个，b 作为 A 的派生类也贡献了 1 个");
    ASSERT(B::num_b == 1, "只有 b 贡献了 1 个");
    ASSERT(a->name() == 'A', "a 是 A 类型");
    ASSERT(b->name() == 'B', "b 是 B 类型");

    delete a;
    delete b;
    ASSERT(A::num_a == 0, "Every A was destroyed");
    ASSERT(B::num_b == 0, "Every B was destroyed");

    A *ab = new B; // 构造 B 时：num_a++, num_b++
    ASSERT(A::num_a == 1, "Fill in the correct value for A::num_a");
    ASSERT(B::num_b == 1, "Fill in the correct value for B::num_b");
    ASSERT(ab->name() == 'B', "虚函数看对象本质，ab 指向的是 B");

    // TODO: 基类指针无法随意转换为派生类指针，补全正确的转换语句
    // 使用 dynamic_cast 确保转换安全（虽然这里已知是 B）
    B &bb = dynamic_cast<B &>(*ab);
    ASSERT(bb.name() == 'B', "Fill in the correct value for bb->name()");

    // TODO: ---- 以下代码不要修改，通过改正类定义解决编译问题 ----
    // 如果 ~A() 不是 virtual，这里 delete ab 只会调用 ~A()，num_b 就无法减回到 0
    delete ab; 
    ASSERT(A::num_a == 0, "Every A was destroyed");
    ASSERT(B::num_b == 0, "Every B was destroyed");

    return 0;
}