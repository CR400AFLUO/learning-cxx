﻿#include "../exercise.h"
#include <cstring>

// READ: 类模板 <https://zh.cppreference.com/w/cpp/language/class_template>

template<class T>
struct Tensor4D {
    unsigned int shape[4];
    T *data;

    Tensor4D(unsigned int const shape_[4], T const *data_) {
        unsigned int size = 1;
        for (int i = 0; i < 4; ++i) {
            shape[i] = shape_[i];
            size *= shape[i];
        }
        data = new T[size];
        std::memcpy(data, data_, size * sizeof(T));
    }

    ~Tensor4D() {
        delete[] data;
    }

    // 为了保持简单，禁止复制和移动
    Tensor4D(Tensor4D const &) = delete;
    Tensor4D(Tensor4D &&) noexcept = delete;

    // 核心逻辑：广播加法
    Tensor4D &operator+=(Tensor4D const &others) {
        unsigned int size = shape[0] * shape[1] * shape[2] * shape[3];
        
        for (unsigned int i = 0; i < size; ++i) {
            // 1. 将平铺索引 i 映射回当前 Tensor 的 4D 坐标 (i0, i1, i2, i3)
            unsigned int i3 = i % shape[3];
            unsigned int i2 = (i / shape[3]) % shape[2];
            unsigned int i1 = (i / (shape[3] * shape[2])) % shape[1];
            unsigned int i0 = (i / (shape[3] * shape[2] * shape[1])) % shape[0];

            // 2. 根据广播规则计算 others 的对应坐标 (o0, o1, o2, o3)
            // 如果 others 在该维度长度为 1，则无论 i 是多少，对应的 o 始终为 0
            unsigned int o0 = (others.shape[0] == 1) ? 0 : i0;
            unsigned int o1 = (others.shape[1] == 1) ? 0 : i1;
            unsigned int o2 = (others.shape[2] == 1) ? 0 : i2;
            unsigned int o3 = (others.shape[3] == 1) ? 0 : i3;

            // 3. 计算 others 的平铺索引并相加
            unsigned int others_idx = o3 + 
                                     o2 * (others.shape[3]) + 
                                     o1 * (others.shape[3] * others.shape[2]) + 
                                     o0 * (others.shape[3] * others.shape[2] * others.shape[1]);
            
            data[i] += others.data[others_idx];
        }
        return *this;
    }
};

// ---- 不要修改以下代码 ----
// ... (main 函数部分保持不变)
// ---- 不要修改以下代码 ----
int main(int argc, char **argv) {
    {
        unsigned int shape[]{1, 2, 3, 4};
        int data[]{
             1,  2,  3,  4,
             5,  6,  7,  8,
             9, 10, 11, 12,
            13, 14, 15, 16,
            17, 18, 19, 20,
            21, 22, 23, 24};
        auto t0 = Tensor4D(shape, data);
        auto t1 = Tensor4D(shape, data);
        t0 += t1;
        for (auto i = 0u; i < sizeof(data) / sizeof(*data); ++i) {
            ASSERT(t0.data[i] == data[i] * 2, "Tensor doubled by plus its self.");
        }
    }
    {
        unsigned int s0[]{1, 2, 3, 4};
        float d0[]{
            1, 1, 1, 1,
            2, 2, 2, 2,
            3, 3, 3, 3,
            4, 4, 4, 4,
            5, 5, 5, 5,
            6, 6, 6, 6};
        unsigned int s1[]{1, 2, 3, 1};
        float d1[]{ 6, 5, 4, 3, 2, 1};

        auto t0 = Tensor4D(s0, d0);
        auto t1 = Tensor4D(s1, d1);
        t0 += t1;
        for (auto i = 0u; i < sizeof(d0) / sizeof(*d0); ++i) {
            ASSERT(t0.data[i] == 7.f, "Every element of t0 should be 7 after adding t1 to it.");
        }
    }
    {
        unsigned int s0[]{1, 2, 3, 4};
        double d0[]{
             1,  2,  3,  4,
             5,  6,  7,  8,
             9, 10, 11, 12,
            13, 14, 15, 16,
            17, 18, 19, 20,
            21, 22, 23, 24};
        unsigned int s1[]{1, 1, 1, 1};
        double d1[]{1};

        auto t0 = Tensor4D(s0, d0);
        auto t1 = Tensor4D(s1, d1);
        t0 += t1;
        for (auto i = 0u; i < sizeof(d0) / sizeof(*d0); ++i) {
            ASSERT(t0.data[i] == d0[i] + 1, "Every element of t0 should be incremented by 1 after adding t1 to it.");
        }
    }
    return 0;
}