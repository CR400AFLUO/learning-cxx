﻿#include "../exercise.h"
#include <vector>
#include <iostream>

// READ: std::vector <https://zh.cppreference.com/w/cpp/container/vector_bool>
// READ: 模板特化 <https://zh.cppreference.com/w/cpp/language/template_specialization>

int main(int argc, char **argv) {
    // 调用构造函数：100 个元素，全部初始化为 true
    std::vector<bool> vec(100, true);
    ASSERT(vec[0], "Make this assertion pass.");
    ASSERT(vec[99], "Make this assertion pass.");
    ASSERT(vec.size() == 100, "Make this assertion pass.");
    
    // NOTICE: 平台相关！
    // 在主流 64 位 Linux (如 Ubuntu) 下，std::vector<bool> 对象本身大小通常是 40 字节
    // (比普通的 24 字节多，因为它需要额外的位偏移信息来定位位数据)
    std::cout << "sizeof(std::vector<bool>) = " << sizeof(std::vector<bool>) << std::endl;
    ASSERT(sizeof(vec) == 40, "Fill in the correct value.");

    {
        vec[20] = false;
        ASSERT(!vec[20], "Fill in `vec[20]` or `!vec[20]`.");
    }
    {
        vec.push_back(false);
        ASSERT(vec.size() == 101, "Fill in the correct value.");
        ASSERT(!vec[100], "Fill in `vec[100]` or `!vec[100]`.");
    }
    {
        // 关键点：ref 实际上是一个代理对象
        auto ref = vec[30]; 
        ASSERT(ref, "Fill in `ref` or `!ref`配置为 true");
        
        ref = false; // 修改代理对象会反映到原 vector 中
        ASSERT(!ref, "Fill in `ref` or `!ref`现在是 false");
        
        // THINK: 代理对象持有对位数据的引用，因此原容器对应位置也变了
        ASSERT(!vec[30], "Fill in `vec[30]` or `!vec[30]`.");
    }
    return 0;
}