#include "../exercise.h"

class DynFibonacci {
    size_t *cache;
    int cached;

public:
    // TODO: 实现动态设置容量的构造器
    // 初始化时，我们已知 F(0)=0, F(1)=1，所以 cached 设为 1
    DynFibonacci(int capacity) : cache(new size_t[capacity]), cached(1) {
        if (capacity > 0) cache[0] = 0;
        if (capacity > 1) cache[1] = 1;
    }

    // TODO: 实现复制构造器
    // ⚠ 注意：这里必须实现深拷贝，为新对象分配独立的内存空间
    DynFibonacci(DynFibonacci const &other) : cache(new size_t[other.cached + 1]), cached(other.cached) {
        for (int i = 0; i <= cached; ++i) {
            cache[i] = other.cache[i];
        }
    }

    // TODO: 实现析构器，释放缓存空间
    ~DynFibonacci() {
        delete[] cache;
    }

    // TODO: 实现正确的缓存优化斐波那契计算
    size_t get(int i) {
        // 从上一次缓存到的位置（cached）开始计算，直到满足请求的 i
        for (; cached < i; ++cached) {
            cache[cached + 1] = cache[cached] + cache[cached - 1];
        }
        return cache[i];
    }

    // NOTICE: 不要修改这个方法
    size_t get(int i) const {
        if (i <= cached) {
            return cache[i];
        }
        ASSERT(false, "i out of range");
    }
};

int main(int argc, char **argv) {
    DynFibonacci fib(12);
    ASSERT(fib.get(10) == 55, "fibonacci(10) should be 55");
    
    // 这里会触发复制构造函数
    DynFibonacci const fib_ = fib;
    ASSERT(fib_.get(10) == fib.get(10), "Object cloned");
    return 0;
}