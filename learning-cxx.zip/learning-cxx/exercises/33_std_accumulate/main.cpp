﻿#include "../exercise.h"
#include <numeric> // std::accumulate 的头文件
#include <functional> // std::multiplies 的头文件

// READ: `std::accumulate` <https://zh.cppreference.com/w/cpp/algorithm/accumulate>

int main(int argc, char **argv) {
    using DataType = float;
    int shape[]{1, 3, 224, 224};

    // TODO: 调用 `std::accumulate` 计算：
    // 1. 计算元素总数：将 shape 数组中的所有维度累乘
    // std::accumulate 默认是加法，这里我们需要传入 std::multiplies<int>()
    int num_elements = std::accumulate(std::begin(shape), std::end(shape), 1, std::multiplies<int>());

    // 2. 计算字节总数：元素总数 * 每个元素的大小
    int size = num_elements * sizeof(DataType);

    ASSERT(size == 602112, "4x1x3x224x224 = 602112");
    return 0;
}